module.exports = {
    mongUrl:"mongodb://localhost:27017/cmzBlog",
}